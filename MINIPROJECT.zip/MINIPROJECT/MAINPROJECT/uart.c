/*#include<LPC21xx.h>
#include"defines.h"
#include"PinConnect.h"
#include"types.h"
void InitUART(void)
{
	//PINSEL0|=0x00000005;
	CfgPinFunc(0,0,1);//P0.0 for TXD0
	CfgPinFunc(0,1,1);//P0.1 for RXD0

	U0LCR=0x03;//8-bit wordlength with1 stop bit
	U0LCR|=1<<7;//DLAB=1
	U0DLL=97;
	U0DLM=0;
	U0LCR&=~(1<<7);//DLAB=0
	
}
s8 UARTRxChar(void)
{
		while(!READBIT(U0LSR,0));
		return (U0RBR);

}
void UARTTxChar(s8 ch)
{
	U0THR=ch;
	while(!READBIT(U0LSR,6));
}

void UARTTxStr(char *ptr)
{
	while(*ptr)
		UARTTxChar(*ptr++);
	
}
void UARTTxu32(u32 num)
{
    u8 buf[10];
    s8 i = 0;

    if(num == 0)
    {
        UARTTxChar('0');
        return;
    }

    while(num)
    {
        buf[i++] = (num % 10) + '0';
        num /= 10;
    }

    while((--i)>=0)
        UARTTxChar(buf[i]);
}

-----------------------------------------
  Transmit float (6 decimal places)
-----------------------------------------
void UARTTxF32(f32 fnum)
{
    u32 int_part;
    u8 i;

    if(fnum < 0)
    {
        UARTTxChar('-');
        fnum = -fnum;
    }

    int_part = fnum;
    UARTTxu32(int_part);
    UARTTxChar('.');
		fnum = (fnum - int_part);
    for(i = 0; i < 6; i++)
    {
        fnum = (fnum) * 10;
		}
        int_part = (u32)fnum;
        UARTTxu32(int_part);
}*/



#include <LPC21xx.h>        // LPC21xx microcontroller register definitions
#include "defines.h"        // Macro definitions
#include "PinConnect.h"     // Pin function configuration functions
#include "types.h"          // Custom data types (u8, s8, u32, f32, etc.)

// =============================
// UART INITIALIZATION FUNCTION
// =============================
void InitUART(void)
{
    // Configure P0.0 as TXD0 (UART0 Transmit)
	CfgPinFunc(0,0,1);   // Port 0, Pin 0, Function 1 ? TXD0

    // Configure P0.1 as RXD0 (UART0 Receive)
	CfgPinFunc(0,1,1);   // Port 0, Pin 1, Function 1 ? RXD0

    // Configure UART: 8-bit word length, 1 stop bit, no parity
	U0LCR = 0x03;        // 8-bit data, 1 stop bit, no parity

    // Enable DLAB (Divisor Latch Access Bit) to set baud rate
	U0LCR |= 1 << 7;     // DLAB = 1

    // Set baud rate divisor (for 9600 baud @ 15MHz PCLK approx)
	U0DLL = 97;          // Divisor Latch Low byte
	U0DLM = 0;           // Divisor Latch High byte

    // Disable DLAB after setting baud rate
	U0LCR &= ~(1 << 7);  // DLAB = 0
}

// =============================
// UART RECEIVE CHARACTER
// =============================
s8 UARTRxChar(void)
{
    // Wait until data is received (LSR bit 0 = RDR = 1)
	while(!READBIT(U0LSR, 0));

    // Read received character from Receive Buffer Register
	return (U0RBR);
}

// =============================
// UART TRANSMIT SINGLE CHARACTER
// =============================
void UARTTxChar(s8 ch)
{
    // Load character into Transmit Holding Register
	U0THR = ch;

    // Wait until transmission is complete (LSR bit 6 = TEMT = 1)
	while(!READBIT(U0LSR, 6));
}

// =============================
// UART TRANSMIT STRING
// =============================
void UARTTxStr(char *ptr)
{
    // Send characters one by one until null character
	while(*ptr)
		UARTTxChar(*ptr++);
}

// =============================
// UART TRANSMIT UNSIGNED 32-BIT INTEGER
// =============================
void UARTTxu32(u32 num)
{
    u8 buf[10];   // Buffer to store digits
    s8 i = 0;     // Index variable

    // If number is zero, print '0'
    if(num == 0)
    {
        UARTTxChar('0');
        return;
    }

    // Convert number to digits (reverse order)
    while(num)
    {
        buf[i++] = (num % 10) + '0';   // Extract digit and convert to ASCII
        num /= 10;                     // Remove last digit
    }

    // Transmit digits in correct order
    while((--i) >= 0)
        UARTTxChar(buf[i]);
}

/*-----------------------------------------
  UART TRANSMIT FLOAT VALUE
  (6 decimal places precision)
-----------------------------------------*/
void UARTTxF32(f32 fnum)
{
    u32 int_part;   // Integer part of float
    u8 i;           // Loop variable

    // If number is negative, print '-' and make it positive
    if(fnum < 0)
    {
        UARTTxChar('-');
        fnum = -fnum;
    }

    // Extract integer part
    int_part = fnum;

    // Transmit integer part
    UARTTxu32(int_part);

    // Transmit decimal point
    UARTTxChar('.');

    // Extract fractional part
	fnum = (fnum - int_part);

    // Shift decimal part to get 6 digits
    for(i = 0; i < 6; i++)
    {
        fnum = (fnum) * 10;
	}

    // Convert fractional part to integer
    int_part = (u32)fnum;

    // Transmit fractional part
    UARTTxu32(int_part);
}
