#include"types.h"
void InitUART(void);
void UARTTxChar(s8);
void UARTTxStr(char *);
s8 UARTRxChar(void);
void UARTTxu32(u32 num);
void UARTTxF32(f32 fnum);

	
