#include<LPC21xx.h>
#include"types.h"

// -------- Keypad Row Pins (Outputs) --------
#define R0 24   // Row 0 connected to P1.24
#define R1 25   // Row 1 connected to P1.25
#define R2 26   // Row 2 connected to P1.26
#define R3 27   // Row 3 connected to P1.27

// -------- Keypad Column Pins (Inputs) --------
#define C0 28   // Column 0 connected to P1.28
#define C1 29   // Column 1 connected to P1.29
#define C2 30   // Column 2 connected to P1.30
#define C3 31   // Column 3 connected to P1.31

// -------- Keypad Lookup Table (4x4 Matrix) --------
// Maps row & column index to actual key value
u8 LUT[][4] = {
    {'7','8','9','A'},   // Row 0
    {'4','5','6','*'},   // Row 1
    {'1','2','3','B'},   // Row 2
    {'C','0','D','+'}    // Row 3
};						 

