// lm35.c
#include "types.h"
#include "adc.h"
#include "adc_defines.h"

/*-------------------------------------------------
  Function: Read_LM35
  Purpose : Read temperature from LM35 sensor
  Input   : tType ? 'C' for Celsius, 'F' for Fahrenheit
  Return  : Temperature value
--------------------------------------------------*/
f32 Read_LM35(u8 tType)
{
	u32 adcDVal;     // Digital ADC value
	f32 eAR;         // Analog voltage from ADC
	f32 tDeg;        // Temperature value

	// Read ADC channel connected to LM35
	Read_ADC(CH1, &eAR, &adcDVal);

	// LM35 output = 10mV per �C ? Temp = Voltage * 100
	tDeg = eAR * 100;

	// Convert to Fahrenheit if required
	if(tType == 'C')
	{
		// Keep in Celsius
	}
	else if(tType == 'F')
	{
		tDeg = ((tDeg * (9.0/5.0)) + 32.0);
	}

	// Return temperature
	return tDeg;
}
