#include "display.h"     // Display related function declarations
#include "lcd.h"         // LCD driver functions
#include "uart.h"        // UART communication functions
#include "rtc.h"         // RTC (Real Time Clock) functions
#include "defines.h"     // Macro definitions
#include "lpc21xx.h"     // LPC21xx microcontroller register definitions
#include "delay.h"       // Delay functions

// External variable for temperature set point (defined in another file)
extern s32 set_point;

// Array to store week day names
static char week[][4] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};

// =============================
// DISPLAY DATA FUNCTION
// =============================
void Display_Data(s32 temp)
{
    // Variables to store time
    s32 hour, min, sec;

    // Variables to store date
    s32 date, month, year;

    // Variable to store day of week
    s32 day;
	
    // Static variable to track previous minute
    // Used to log UART data only when minute changes
    static s32 prev_min = -1;

    // Read time from RTC
    GetRTCTimeInfo(&hour, &min, &sec);

    // Read date from RTC
    GetRTCDateInfo(&date, &month, &year);

    // Read day from RTC
    GetRTCDay(&day);
	
    // Clear LCD screen
	CmdLCD(0x01);

    // Move cursor to first line
    CmdLCD(0x80);

    // Display hour (tens digit)
    CharLCD(hour / 10 + '0');

    // Display hour (units digit)
    CharLCD(hour % 10 + '0');

    // Display colon
    CharLCD(':');

    // Display minute (tens digit)
    CharLCD(min / 10 + '0');

    // Display minute (units digit)
    CharLCD(min % 10 + '0');

    // Display colon
    CharLCD(':');

    // Display second (tens digit)
    CharLCD(sec / 10 + '0');

    // Display second (units digit)
    CharLCD(sec % 10 + '0');

    // Space after time
    CharLCD(' ');

    // Display weekday string (SUN, MON, etc.)
    StrLCD(week[day]);

    // Move cursor to second line
    CmdLCD(0xC0);

    // Display date (tens digit)
    CharLCD(date / 10 + '0');

    // Display date (units digit)
    CharLCD(date % 10 + '0');

    // Display '/'
    CharLCD('/');

    // Display month (tens digit)
    CharLCD(month / 10 + '0');

    // Display month (units digit)
    CharLCD(month % 10 + '0');

    // Display '/'
    CharLCD('/');

    // Display year (last two digits � tens)
    CharLCD((year % 100) / 10 + '0');

    // Display year (last two digits � units)
    CharLCD((year % 100) % 10 + '0');

    // Space
    CharLCD(' ');

    // Display 'T'
    CharLCD('T');

    // Display ':'
    CharLCD(':');

    // Display temperature value
    IntLCD(temp);

    // Display degree symbol (�)
    CharLCD(0xDF);        

    // Display 'C'
    CharLCD('C');
	
    // Delay for 1 second
	delay_ms(1000);
		
    // Check if minute has changed (for UART logging control)
    if (min != prev_min)
    {
        // Update previous minute
        prev_min = min;

        // Send temperature info via UART
        UARTTxStr("[INFO] Temp:");
        UARTTxu32(temp);
        UARTTxStr("C @ ");

        // Send hour with leading zero if needed
        if (hour < 10) 
			UARTTxChar('0');
        UARTTxu32(hour);
        UARTTxChar(':');

        // Send minute with leading zero if needed
        if (min < 10) 
			UARTTxChar('0');
        UARTTxu32(min);
        UARTTxChar(':');

        // Send second with leading zero if needed
        if (sec < 10) 
			UARTTxChar('0');
        UARTTxu32(sec);

        // Space separator
        UARTTxStr(" ");

        // Send date with leading zero if needed
        if (date < 10) 
			UARTTxChar('0');
        UARTTxu32(date);
        UARTTxChar('/');

        // Send month with leading zero if needed
        if (month < 10) 
			UARTTxChar('0');
        UARTTxu32(month);
        UARTTxChar('/');

        // Send full year
        UARTTxu32(year);
	}
}

