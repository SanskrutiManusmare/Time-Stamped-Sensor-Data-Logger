#ifndef EDIT_H
#define EDIT_H

//void Edit_Mode(void);
//void Edit_RTC_Info(void);
void edit_menu(void);
static int set_multi(char *str);
void rtc_edit(void);

#endif
