// adc_defines.h

// -------- System Clock Definitions --------
#define FOSC 12000000          // External crystal frequency = 12 MHz
#define CCLK (FOSC*5)          // CPU clock frequency = 60 MHz
#define PCLK (CCLK/4)          // Peripheral clock = 15 MHz
#define ADCCLK 3000000         // ADC operating clock = 3 MHz
#define CLKDIV ((PCLK/ADCCLK)-1) // ADC clock divider value

// -------- ADCR (ADC Control Register) Bit Definitions --------
#define CLKDIV_BITS        8   // Clock divider bit position (bits 8�15)
#define PDN_BIT            21  // Power-down bit (1 = ADC ON)
#define ADC_CONV_START_BIT 24  // Start conversion bit

// -------- ADDR (ADC Data Register) Bit Definitions --------
#define DIGITAL_DATA_BITS  6   // ADC result bit position (bits 6�15)
#define DONE_BIT           31  // Conversion complete flag bit

// -------- ADC Pin Configuration (PINSEL1 values) --------
#define AIN0_PIN_0_27 0x00400000  // P0.27 configured as AIN0
#define AIN1_PIN_0_28 0x01000000  // P0.28 configured as AIN1
#define AIN2_PIN_0_29 0x04000000  // P0.29 configured as AIN2
#define AIN3_PIN_0_30 0x10000000  // P0.30 configured as AIN3

// -------- ADC Channel Numbers --------
#define CH0 0   // ADC Channel 0 (AIN0)
#define CH1 1   // ADC Channel 1 (AIN1)
#define CH2 2   // ADC Channel 2 (AIN2)
#define CH3 3   // ADC Channel 3 (AIN3)

// Add more channel and pin defines as required
