//lm35.h
#include "types.h"
//void Read_LM35(f32 *tdegC,f32 *tdegF);
f32 Read_LM35(u8 tType);
//f32 Read_LM35_NP(u8 tType);

