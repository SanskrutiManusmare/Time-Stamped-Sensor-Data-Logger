#include<LPC21XX.h>
#include"types.h"
#include"KeyPdDefines.h"

/*-------------------------------------------------
  Function: KeyPdInit
  Purpose : Initialize keypad rows as output pins
--------------------------------------------------*/
void KeyPdInit(void)
{
	// Set row pins (R0�R3) as OUTPUT
	IODIR1 |= (1<<R0)|(1<<R1)|(1<<R2)|(1<<R3);
}

/*-------------------------------------------------
  Function: ColStat
  Purpose : Check if any key is pressed
  Return  : 1 ? No key pressed
            0 ? Any key pressed
--------------------------------------------------*/
int ColStat(void)
{
	// Read column pins (C0�C3)
	// If all columns are HIGH (1111), no key is pressed
	if(((IOPIN1>>C0)&0xf) == 0x0f)
	{
		return 1;   // No key pressed
	}
	return 0;       // Key pressed
}

/*-------------------------------------------------
  Function: KeyVal
  Purpose : Detect pressed key and return its value
--------------------------------------------------*/
char KeyVal(void)
{
	s8 rowval, colval;   // Variables to store row and column index
	
	/* -------- Row scanning -------- */

	// Activate Row 0 (LOW), others HIGH
	IOCLR1 = 1<<R0;
	IOSET1 = (1<<R1)|(1<<R2)|(1<<R3);

	// Check if any column is LOW
	if(((IOPIN1>>C0) & 0xf) != 0xf)
	{
		rowval = 0;      // Key is in row 0
		goto colcheak;   // Jump to column check
	}
	
	// Activate Row 1
	IOCLR1 = 1<<R1;
	IOSET1 = (1<<R0)|(1<<R2)|(1<<R3);
	if(((IOPIN1 >> C0) & 0xf) != 0xf)
	{
		rowval = 1;      // Key is in row 1
		goto colcheak;
	}
	
	// Activate Row 2
	IOCLR1 = 1<<R2;
	IOSET1 = (1<<R0)|(1<<R1)|(1<<R3);
	if(((IOPIN1 >> C0) & 0xf) != 0xf)
	{
		rowval = 2;      // Key is in row 2
		goto colcheak;
	}

	// Activate Row 3
	IOCLR1 = 1<<R3;
	IOSET1 = (1<<R0)|(1<<R1)|(1<<R2);
	if(((IOPIN1 >> C0) & 0xf) != 0xf)
	{
		rowval = 3;      // Key is in row 3
		goto colcheak;
	}
	
/* -------- Column detection -------- */
colcheak:

	// Check which column is LOW
	if(((IOPIN1 >> C0) & 1) == 0)
	{
		colval = 0;
	}
	else if(((IOPIN1 >> C1) & 1) == 0)
	{
		colval = 1;
	}
	else if(((IOPIN1 >> C2) & 1) == 0)
	{
		colval = 2;
	}
	else
	{
		colval = 3;
	}
		
	// Wait until key is released (key debounce handling)
	while(((IOPIN1 >> C0) & 0xf) != 0xf);

	// Return key value from lookup table
	return LUT[rowval][colval];
}

