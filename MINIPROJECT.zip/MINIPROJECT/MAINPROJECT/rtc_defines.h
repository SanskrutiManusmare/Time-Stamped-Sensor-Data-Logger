#ifndef RTC_DEFINES_H
#define RTC_DEFINES_H

// -------- System Clock Definitions --------
#define FOSC 12000000        // External crystal frequency = 12 MHz
#define CCLK (5*FOSC)       // CPU clock frequency = 60 MHz
#define PCLK (CCLK/4)       // Peripheral clock frequency = 15 MHz

// -------- RTC Prescaler Values --------
// Used to generate 32.768 kHz RTC clock from PCLK
#define PREINT_VAL  ((PCLK/32768)-1)              // Integer prescaler value
#define PREFRAC_VAL (PCLK-(PREINT_VAL+1)*32768)   // Fractional prescaler value

// -------- CCR (Clock Control Register) Bits --------
#define RTC_ENABLE  (1<<0)   // Enable RTC
#define RTC_RESET   (1<<1)   // Reset RTC counters
#define RTC_CLKSRC  (1<<4)   // Select RTC clock source

// #define _LPC2148    // MCU selection macro (optional / future use)

#endif
