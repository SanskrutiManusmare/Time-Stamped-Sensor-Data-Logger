#include "types.h"
void Display_Data(s32 temp);
