// adc.c
#include "types.h"
#include "delay.h"
#include <LPC21xx.h>
#include "adc_defines.h"

/*-------------------------------------------------
  Function: Init_ADC
  Purpose : Initialize ADC peripheral and pins
--------------------------------------------------*/
void Init_ADC(void)
{
	// Clear previous pin configuration of P0.27 � P0.30
	// (These pins are used for ADC channels AIN0�AIN3)
	PINSEL1 &= ~(255<<22);

	// Configure pins as ADC inputs:
	// P0.27 ? AIN0
	// P0.28 ? AIN1
	// P0.29 ? AIN2
	// P0.30 ? AIN3
	PINSEL1 |= AIN0_PIN_0_27 | AIN1_PIN_0_28 |
	           AIN2_PIN_0_29 | AIN3_PIN_0_30;

	// Configure ADC Control Register (ADCR):
	// PDN_BIT   ? Power ON ADC
	// CLKDIV    ? Set ADC clock divider
	ADCR |= (1<<PDN_BIT) | (CLKDIV<<CLKDIV_BITS);
}

/*-------------------------------------------------
  Function: Read_ADC
  Purpose : Read ADC value from selected channel
  Inputs  : chNo     ? ADC channel number (0�7)
            eAR      ? pointer to store analog voltage
            adcDVal  ? pointer to store digital ADC value
--------------------------------------------------*/
void Read_ADC(u32 chNo, f32 *eAR, u32 *adcDVal)
{
	// Clear any previously selected ADC channel
	ADCR &= 0xFFFFFF00;

	// Select required ADC channel
	// Start ADC conversion
	ADCR |= ((1<<ADC_CONV_START_BIT) | (1<<chNo));

	// Small delay for conversion start time
	delay_us(3);

	// Wait until ADC conversion is completed
	// DONE_BIT = 1 ? Conversion complete
	while(((ADDR >> DONE_BIT) & 1) == 0);

	// Stop ADC conversion
	ADCR &= ~(1<<ADC_CONV_START_BIT);

	// Read 10-bit digital ADC result from ADDR register
	// DIGITAL_DATA_BITS ? starting bit position of ADC result
	*adcDVal = ((ADDR >> DIGITAL_DATA_BITS) & 1023);

	// Convert digital value to analog voltage
	// Formula: Voltage = (ADC_Value / 1023) * Vref
	// Here Vref = 3.3V
	*eAR = *adcDVal * (3.3 / 1023);
}
