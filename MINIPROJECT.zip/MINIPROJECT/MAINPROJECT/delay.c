// Microsecond delay function
void delay_us(unsigned int tdly)
{
	tdly*=12;
	while(tdly--);
}


// Milisecond delay function
void delay_ms(unsigned int tdly)
{
	tdly*=12000;
	while(tdly--);
}


//Second delay function
void delay_s(unsigned int tdly)
{
	tdly*=12000000;
	while(tdly--);
}
