#include<LPC21xx.h>
#include"delay.h"
#include"lcd.h"
#include"types.h"
#include"defines.h"

/* LCD Data lines connected to Port1:
   P1.16 � P1.23 used for LCD D0 � D7 (8-bit mode) */
#define LCD_DAT (0xff<<16)   // Mask for P1.16�P1.23

// LCD control pins connected to Port0
#define RS 8   // Register Select  -> P0.8
#define RW 9   // Read/Write       -> P0.9
#define EN 10  // Enable            -> P0.10

/*-------------------------------------------------
  Function: InitLCD
  Purpose : Initializes LCD in 8-bit mode
--------------------------------------------------*/
void InitLCD(void)
{
	// Set LCD data pins (P1.16�P1.23) as OUTPUT
	IODIR1 |= LCD_DAT;
	
	// Set LCD control pins (RS, RW, EN) as OUTPUT
	IODIR0 |= ((1<<RS)|(1<<RW)|(1<<EN));

	// Initial power-on delay (LCD needs stabilization time)
	delay_ms(20);   // Minimum 15 ms required
	
	// LCD reset sequence (as per HD44780 datasheet)
	CmdLCD(0x30);   // 8-bit mode
	delay_ms(10);   // Minimum 5 ms
	CmdLCD(0x30);   // 8-bit mode
	delay_ms(1);    // Minimum 160 �s
	CmdLCD(0x30);   // 8-bit mode
	delay_ms(1);    // Minimum 160 �s

	// LCD configuration commands
	CmdLCD(0x38);   // 8-bit, 2 lines, 5x7 font
	CmdLCD(0x10);   // Display OFF
	CmdLCD(0x01);   // Clear display
	CmdLCD(0x06);   // Cursor move right, no display shift
	CmdLCD(0x0f);   // Display ON, Cursor ON, Blinking ON
}

/*-------------------------------------------------
  Function: CmdLCD
  Purpose : Send command to LCD
--------------------------------------------------*/
void CmdLCD(u8 cmd)
{
	IOCLR0 = 1<<RS;   // RS = 0 ? Command mode
	DispLCD(cmd);    // Send command byte
}

/*-------------------------------------------------
  Function: CharLCD
  Purpose : Send single character (data) to LCD
--------------------------------------------------*/
void CharLCD(u8 dat)
{
	IOSET0 = 1<<RS;   // RS = 1 ? Data mode
	DispLCD(dat);    // Send data byte
}

/*-------------------------------------------------
  Function: DispLCD
  Purpose : Low-level LCD data/command transfer
--------------------------------------------------*/
void DispLCD(u8 val)
{
	IOCLR0 = 1<<RW;   // RW = 0 ? Write mode
	
	// Clear old data on data bus
	IOCLR1 = LCD_DAT;

	// Put new data on data bus (P1.16�P1.23)
	IOSET1 = ((u32)val<<16);

	// Enable pulse to latch data into LCD
	IOSET0 = 1<<EN;   // EN = 1
	delay_ms(2);      // Enable pulse width delay
	IOCLR0 = 1<<EN;   // EN = 0
	delay_ms(5);      // Command execution delay
}

/*-------------------------------------------------
  Function: StrLCD
  Purpose : Display string on LCD
--------------------------------------------------*/
void StrLCD(char *ptr)
{
	while(*ptr!='\0')     // Loop till end of string
		CharLCD(*ptr++);  // Send each character
}

/*-------------------------------------------------
  Function: IntLCD
  Purpose : Display integer number on LCD
--------------------------------------------------*/
void IntLCD(s32 num)
{
	u8 a[10];   // Buffer to store digits
	s8 i=0;

	// If number is 0
	if(num==0)
		CharLCD('0');
	else
	{
		// If number is negative
		if(num<0)
		{
			num=-num;        // Make positive
			CharLCD('-');   // Print minus sign
		}

		// Extract digits (reverse order)
		while(num>0)
		{
			a[i++] = num%10 + 48;  // Convert digit to ASCII
			num = num/10;
		}

		// Print digits in correct order
		for(--i; i>=0; i--)
			CharLCD(a[i]);
	}
}

/*-------------------------------------------------
  Function: FltLCD
  Purpose : Display floating-point number on LCD
--------------------------------------------------*/
void FltLCD(f32 val)
{
    s32 ipart;   // Integer part
    s32 fpart;   // Fractional part

    // Handle negative value
    if(val < 0)
    {
        CharLCD('-');
        val = -val;
    }

    // Extract integer part
    ipart = (s32)val;
    IntLCD(ipart);   // Display integer part

    // Display decimal point
    CharLCD('.');

    // Extract fractional part (2 digits precision)
    fpart = (s32)((val - ipart) * 100);
    IntLCD(fpart);   // Display fractional part
}

/*-------------------------------------------------
  Function: StoreCustCharFont
  Purpose : Store custom character in CGRAM
--------------------------------------------------*/
void StoreCustCharFont(void)
{
	// Custom character pattern (8 bytes = 8 rows)
	u8 i, LUT[] = {
		0x00,
		0x00,
		0x04,
		0x0c,
		0x1c,
		0x1c,
		0x1c,
		0x00
	};

	// Write custom pattern into LCD CGRAM
	for(i=0; i<8; i++)
		CharLCD(LUT[i]);
}





