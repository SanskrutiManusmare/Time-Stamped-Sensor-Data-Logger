//void alert_check(int set_point);
void temp_alert(s32 temperature);
