#include <lpc21xx.h>        // Header file for LPC21xx microcontroller registers
#include "lcd.h"            // LCD driver functions
#include "uart.h"           // UART communication functions
#include "edit.h"           // Edit/menu related functions
#include "adc_defines.h"    // ADC channel and configuration definitions
#include "adc.h"            // ADC driver functions
#include "lm35.h"           // LM35 temperature sensor functions
#include "rtc.h"            // Real Time Clock (RTC) functions
#include "display.h"        // Display formatting functions
#include "delay.h"          // Delay functions
#include "keyPd.h"          // Keypad driver functions
#include "alert.h"          // Alert/buzzer/LED control functions

#define ALERTPIN (1<<11)    // Define ALERT pin at P0.11 (bit 11)
#define LED      (1<<7)     // Define LED pin at P0.7 (bit 7)
#define SWITCH   (1<<14)    // Define SWITCH pin at P0.14 (bit 14)

int sp = 45;                // Set-point temperature value (alert threshold)
s32 temp;                   // Variable to store temperature (signed 32-bit)

int main(void)              // Main function
{
    // Initialize UART communication
    InitUART();             

    // Configure SWITCH pin as input
    // IODIR0 bit = 0 → input
    IODIR0 &= ~SWITCH;      

    // Initialize Real Time Clock
    RTC_Init();             

    // Initialize LCD display
    InitLCD();              

    // Initialize ADC on channel 1
    Init_ADC(CH1);          

    // Initialize keypad
    KeyPdInit();            

    // Set RTC time → 12:30:15
    SetRTCTimeInfo(12, 30, 15);  

    // Set RTC date → 25/02/2026 (DD/MM/YYYY)
    SetRTCDateInfo(25, 02, 2026); 

    // Set RTC day → 3 (e.g., Wednesday depending on implementation)
    SetRTCDay(3);            

    // Configure ALERTPIN and LED as output pins
    IODIR0 |= (ALERTPIN) | (LED);

    // Send startup message on UART
    UARTTxStr("\r\n*TIME-STAMPED SENSOR DATA LOGGER STARTED*\n\r ");

    // Infinite loop
    while(1)
    {
        // Read temperature from LM35 sensor in Celsius
        temp = Read_LM35('C');

        // Display temperature data on LCD
        Display_Data(temp);

        // Check temperature and trigger alert if needed
        temp_alert(temp);

        // Handle edit/menu operations (keypad based)
        edit_menu();
    }
}
