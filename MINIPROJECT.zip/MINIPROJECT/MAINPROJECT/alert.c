#include "types.h"
#include "lpc21xx.h"
#include "uart.h"
#include "rtc.h"

#define ALERTPIN    11   // Alert output pin (P0.11)
#define LED          7   // LED pin (P0.7)

extern s32 sp;           // Set-point temperature (threshold)

/*-------------------------------------------------
  Function: temp_alert
  Purpose : Generate alert if temperature exceeds set-point
--------------------------------------------------*/
void temp_alert(s32 temperature)
{
    s32 hour, min, sec;      // Time variables
    s32 date, month, year;   // Date variables
    s32 day;                 // Day variable

    // Configure LED and ALERT pins as OUTPUT
    // (Ideally this should be done once in init function)
    IODIR0 |= (1<<LED) | (1<<ALERTPIN);

    // Read current time from RTC
    GetRTCTimeInfo(&hour, &min, &sec);

    // Read current date from RTC
    GetRTCDateInfo(&date, &month, &year);

    // Read current day from RTC
    GetRTCDay(&day);

    // Check if temperature exceeds set-point
    if (temperature > sp)
    {
        // Turn ON LED and alert pin
        IOSET0 = (1<<LED);
        IOSET0 = (1<<ALERTPIN);

        // Send alert message via UART
        UARTTxStr("[ALERT] Over Temperature:\n\r ");
        UARTTxu32(temperature);   // Send temperature value
        UARTTxStr("C @ ");

        // Send time in HH:MM:SS format
        if (hour < 10) UARTTxChar('0');
        UARTTxu32(hour);
        UARTTxChar(':');

        if (min < 10) UARTTxChar('0');
        UARTTxu32(min);
        UARTTxChar(':');

        if (sec < 10) UARTTxChar('0');
        UARTTxu32(sec);
        UARTTxStr(" ");

        // Send date in DD/MM/YYYY format
        if (date < 10) UARTTxChar('0');
        UARTTxu32(date);
        UARTTxChar('/');

        if (month < 10) UARTTxChar('0');
        UARTTxu32(month);
        UARTTxChar('/');

        UARTTxu32(year);
        UARTTxStr("\r\n");
    }
    else
    {
        // Turn OFF LED and alert pin
        IOCLR0 = (1<<LED);
        IOCLR0 = (1<<ALERTPIN);
    }
}
