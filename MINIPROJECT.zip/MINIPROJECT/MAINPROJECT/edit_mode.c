#include <lpc214x.h>     // Header file for LPC214x microcontroller register definitions
#include "lcd.h"         // LCD driver functions
#include "keyPd.h"       // Keypad driver functions
#include "rtc.h"         // RTC (Real Time Clock) functions
#include "uart.h"        // UART communication functions
#include "delay.h"       // Delay functions
#include "edit.h"        // Edit menu function declarations
#include "defines.h"     // Macro definitions
#include "types.h"       // Data type definitions (u8, s32, etc.)

#define SWITCH 14        // Define SWITCH pin number (P0.14)

u8 key;                  // Variable to store keypad key value
int edit_flag = 0;       // Flag for edit mode control
extern int sp;           // External variable for set-point temperature (from main file)

/* Function declarations */
static void edit_set_point(void);  // Function to edit temperature set-point
void rtc_edit(void);               // Function to edit RTC values
static int set_multi(char *str);   // Function to take multi-digit input from keypad

/* ================= EDIT MENU FUNCTION ================= */
void edit_menu(void)
{
    // Check if SWITCH is pressed
    if(((IOPIN0 >> SWITCH) & 1))
    {
        // Wait until switch is released (debounce handling)
        while((READBIT(IOPIN0 , SWITCH)) == 0);

        // Send message on UART
        UARTTxStr("*** Time Editing Mode Activated *** \r\n");

        // Clear LCD
        CmdLCD(0x01);

        // Set cursor to first line
        CmdLCD(0X80);
        StrLCD("1.RTC INFO");     // Display RTC edit option

        // Set cursor to second line
        CmdLCD(0xC0);
        StrLCD("2.SET PT 3.EX");  // Display Set-point and Exit options

        // Clear keypad output port nibble
        WRITENIBBLE(IOPIN1,24,0X0);

        // Wait for key press
        while(ColStat());

        // Read key value
        key = KeyVal();

        // Menu selection
        switch(key)
        {
            case '1': 
                rtc_edit();     // Enter RTC edit mode
                break;

            case '2':
                edit_set_point(); // Enter set-point edit mode
                break;

            case '3':            // Exit edit mode
                CmdLCD(0x01);
                StrLCD("EXITING...");
                delay_ms(800);
                edit_flag = 0;
                UARTTxStr("\r\n EXIT EDIT MODE *\r\n");
                return;

            default:
                break;
        }
    }
}

/* ============ MULTI-DIGIT INPUT FUNCTION ============ */
static int set_multi(char *str)
{
    u32 Value1 = 0;   // Stores current key value
    u32 Value2 = 0;   // Stores complete multi-digit number
    u32 i;

    while(1)
    {
        // Clear LCD nibble
        WRITENIBBLE(IOPIN1 ,24, 0x0);

        // Set LCD cursor to first line
        CmdLCD(0x80);

        // Display prompt string
        for(i = 0 ; i < str[i] ; i++)
            CharLCD(str[i]);

        // Wait for key press
        while(ColStat());

        // Read key value
        Value1 = KeyVal();

        // If '*' pressed ? confirm input
        if(Value1 == '*')
        {
            return Value2;   // Return final value
        }

        // If '+' pressed ? backspace
        else if(Value1 == '+')
        {
            Value2 = Value2 / 10;  // Remove last digit
            CmdLCD(0x01);
            CmdLCD(0xc0);
            IntLCD(Value2);       // Display updated value
        }

        // If digit pressed
        else if(Value1 != '+')
        {
            if(Value2 < 9999)     // Limit max value size
            {
                Value2 = Value2 * 10 + (Value1 - '0');  // Append digit
                CmdLCD(0xc0);
                IntLCD(Value2);   // Display number
            }
        }
    }
}

/* ================= RTC EDIT FUNCTION ================= */
void rtc_edit(void)
{
    s32 val;   // Variable to store input value

    while(1)
    {
        // Clear LCD
        CmdLCD(0x01);

        // Display RTC menu
        CmdLCD(0X80);
        StrLCD("1.H 2.M 3.S 4.DAY");

        CmdLCD(0xC0);
        StrLCD("5.D 6.M 7.Y 8.E");

        // Clear keypad nibble
        WRITENIBBLE(IOPIN1,24,0X0);

        // Wait for key press
        while(ColStat());

        // Read key
        key = KeyVal();

        switch(key)
        {
            case '1':   // Set Hour
                CmdLCD(0x01);
                val = set_multi("SET HOUR(0-23)");
                if(val < 23)
                    HOUR = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '2':   // Set Minute
                CmdLCD(0x01);
                val = set_multi("SET MIN(0-59)");
                if(val < 59)
                    MIN = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '3':   // Set Second
                CmdLCD(0x01);
                val = set_multi("SET SEC(0-59)");
                if(val < 59)
                    SEC = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '4':   // Set Day of Week
                CmdLCD(0x01);
                val = set_multi("SET DAY(0-6)");
                if(val >= 1 && val <= 7)
                    DOW = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '5':   // Set Date
                CmdLCD(0x01);
                val = set_multi("SET DATE(1-31)");
                if(val >= 1 && val <= 31)
                    DOM = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '6':   // Set Month
                CmdLCD(0x01);
                val = set_multi("SET MONTH(1-12)");
                if(val >= 1 && val <= 12)
                    MONTH = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '7':   // Set Year
                CmdLCD(0x01);
                val = set_multi("SET YEAR");
                if(val <= 4095)
                    YEAR = val;
                else
                {
                    CmdLCD(0x01);
                    StrLCD("INVALID VALUE");
                    delay_ms(100);
                }
                break;

            case '8':   // Exit RTC edit
                CmdLCD(0x01);
                StrLCD("RTC UPDATED");
                delay_ms(800);
                UARTTxStr("RTC Updated Successfully\r\n");
                return;
        }
    }
}

/* ================= SET-POINT EDIT FUNCTION ================= */
static void edit_set_point(void)
{
    s32 value;   // Variable for set-point value

    // Clear LCD
    CmdLCD(0x01);

    // Get temperature set-point from keypad
    value = set_multi("SET TEMP(10-80)");

    // Validate range
    if (value >= 10 && value <= 80)
    {
        sp = value;          // Update global set-point
        CmdLCD(0x01);
        StrLCD("SETPOINT OK");
    }
    else
    {
        CmdLCD(0x01);
        StrLCD("INVALID VALUE");
    }

    // Delay for user visibility
    delay_ms(800);
}
