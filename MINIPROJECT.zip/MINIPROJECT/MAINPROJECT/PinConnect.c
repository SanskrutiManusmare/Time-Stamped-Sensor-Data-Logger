#include<LPC21xx.h>

/*-------------------------------------------------
  Function: CfgPinFunc
  Purpose : Configure pin function (GPIO / Peripheral)
  Inputs  : PortNo ? Port number (only Port 0 used)
            PinNo  ? Pin number (0�31)
            Func   ? Function select value
                     0 = GPIO
                     1 = Function 1
                     2 = Function 2
                     3 = Function 3
--------------------------------------------------*/
void CfgPinFunc(int PortNo, int PinNo, int Func)
{
	if(PortNo == 0)   // Only Port 0 supported
	{
		if(PinNo < 16)
		{
			// Configure PINSEL0 for P0.0 � P0.15
			PINSEL0 = ((PINSEL0 & ~(3 << (PinNo*2))) | 
			           (Func << (PinNo*2)));
		}
		else
		{
			// Configure PINSEL1 for P0.16 � P0.31
			PINSEL1 = ((PINSEL1 & ~(3 << ((PinNo-16)*2))) | 
			           (Func << ((PinNo-16)*2)));
		}
	}
	else
	{
		// Dummy block (Port 1 not implemented)
	}
}
