#include"types.h"
void KeyPdInit(void);
u8 ColStat(void);
char KeyVal(void);
