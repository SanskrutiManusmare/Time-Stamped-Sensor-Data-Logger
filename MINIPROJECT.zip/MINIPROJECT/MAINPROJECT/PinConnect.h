void CfgPinFunc(int,int,int);
